

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <h2>Failed Orders</h2>
            <p class="text-muted">These orders failed to sync after 3 retry attempts. Please review and handle manually.</p>
            <a href="<?php echo e(route('sync-settings.index')); ?>" class="btn btn-secondary mb-3">
                <i class="fas fa-arrow-left"></i> Back to Sync Settings
            </a>
            <hr>
        </div>
    </div>

    <?php if($failedOrders->count() > 0): ?>
    <div class="row">
        <div class="col-md-12">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>Order ID</th>
                            <th>Order Number</th>
                            <th>SKU</th>
                            <th>Sync Type</th>
                            <th>Retry Count</th>
                            <th>Error Message</th>
                            <th>Last Attempt</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $failedOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($order->order_id); ?></td>
                            <td><?php echo e($order->order_number ?? 'N/A'); ?></td>
                            <td><?php echo e($order->sku ?? 'N/A'); ?></td>
                            <td>
                                <span class="badge badge-<?php echo e($order->sync_type === 'full' ? 'primary' : 'info'); ?>">
                                    <?php echo e(ucfirst($order->sync_type)); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge badge-danger">
                                    <?php echo e($order->retry_count); ?>/<?php echo e($order->max_retries); ?>

                                </span>
                            </td>
                            <td>
                                <small class="text-danger"><?php echo e(Str::limit($order->error_message, 100)); ?></small>
                                <?php if(strlen($order->error_message) > 100): ?>
                                    <button class="btn btn-sm btn-link" onclick="alert('<?php echo e(addslashes($order->error_message)); ?>')">
                                        View Full Error
                                    </button>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(\Carbon\Carbon::parse($order->last_attempt_at)->format('Y-m-d H:i:s')); ?></td>
                            <td>
                                <button class="btn btn-sm btn-warning retry-order" data-id="<?php echo e($order->id); ?>">
                                    <i class="fas fa-redo"></i> Retry
                                </button>
                                <button class="btn btn-sm btn-success resolve-order" data-id="<?php echo e($order->id); ?>">
                                    <i class="fas fa-check"></i> Mark Resolved
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?php echo e($failedOrders->links()); ?>

            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> No failed orders! All orders have been synced successfully.
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('script'); ?>
<script>
$(document).ready(function() {
    // Retry Order
    $('.retry-order').click(function() {
        var orderId = $(this).data('id');
        if(confirm('Are you sure you want to retry syncing this order?')) {
            $.post('/sync-settings/failed-orders/' + orderId + '/retry', {
                _token: '<?php echo e(csrf_token()); ?>'
            })
            .done(function(response) {
                alert(response.message);
                location.reload();
            })
            .fail(function(xhr) {
                alert('Error: ' + (xhr.responseJSON?.message || 'Unknown error'));
            });
        }
    });

    // Resolve Order
    $('.resolve-order').click(function() {
        var orderId = $(this).data('id');
        var notes = prompt('Enter resolution notes (optional):');

        if(notes !== null) { // User didn't click cancel
            $.post('/sync-settings/failed-orders/' + orderId + '/resolve', {
                _token: '<?php echo e(csrf_token()); ?>',
                notes: notes
            })
            .done(function(response) {
                alert(response.message);
                location.reload();
            })
            .fail(function(xhr) {
                alert('Error: ' + (xhr.responseJSON?.message || 'Unknown error'));
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u935545640/domains/myzpanel.com/public_html/irvalda/resources/views/sync-settings/failed-orders.blade.php ENDPATH**/ ?>