

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <?php if(request()->has('message')): ?>
            <h4 id="removemessage" style="padding: 10px;background:green;color: #fff"><?php echo e(request()->get('message')); ?></h4>
            <?php endif; ?>
            <?php if(request()->has('errorMessage')): ?>
            <h4 id="removemessage" style="padding: 10px;background:red;color: #fff"><?php echo e(request()->get('errorMessage')); ?></h4>
            <?php endif; ?>
            <h3>Products <span class="badge badge-primary"><?php echo e(count($products)); ?></span> <div class="pull-right"><a href="<?php echo e(route('check-live')); ?>" class="btn btn-success" >Check For Live</a> <a href="<?php echo e(route('check-status')); ?>" class="btn btn-danger" >Check For Errors</a> <a href="<?php echo e(route('check-stock')); ?>" class="btn btn-primary" >Check Stock</a> <!-- <a href="<?php echo e(route('fetch-products')); ?>" class="btn btn-primary" style="  background-color: #dc356f;border-color:  #dc356f">Fetch Products From Shopify</a>  --> <a href="<?php echo e(route('push-products')); ?>" class="btn btn-warning">Push Products To Zalando</a> <a href="<?php echo e(route('add-product')); ?>" class="btn btn-danger">Add Product</a></div></h3>
            <br>
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                   <thead>
                       <tr>
                           <th width="3%">ID</th>
                           <th width="25%">Title</th>
                           <th width="15%">Body</th>
                           <th width="15%">Tags</th>
                           <th width="12%">Created At</th>
                           <th width="10%">Status</th>
                           <th width="20%">Action</th>
                       </tr>
                   </thead>

                   <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr <?php echo !is_null($p->errors) && $p->errors->count() > 0?'style="background:red;color:white"':''; ?>>
                       <td><?php echo e($p->merchant_product_model_id); ?></td>
                       <td><?php echo e($p->title); ?></td>
                       <td><?php echo str_limit($p->body_html, 20); ?></td>
                       <td><?php echo e($p->tags); ?></td>
                       <td><?php echo e(date('d M Y',strtotime($p->created_at))); ?></td>
                       <td>
                        <?php if($p->imported == 1): ?>
                        Awaiting Approval
                        <?php elseif($p->imported == 2): ?>
                        Completed
                        <?php elseif($p->imported == 3): ?>
                        Push Prices
                        <?php elseif($p->imported == 4): ?>
                        Price Pushed
                        <?php else: ?>
                        Pending
                        <?php endif; ?></td>
                       <td><!-- <?php if($p->imported != 1): ?><a href="<?php echo e(url('resubmit-product/'.$p->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-sync-alt"></i></a><?php endif; ?>  -->
                        <a href="<?php echo e(route('edit-product',$p->id)); ?>" class="btn  btn-warning btn-sm"><i class="fas fa-edit"></i></a>
                        
                        <a href="<?php echo e(route('push-prices',$p->id)); ?>" title="Push Prices" class="btn  btn-primary btn-sm"><i class="fas fa-money-check-alt"></i></a>
                        
                        <a href="<?php echo e(route('delete-product',$p->id)); ?>" onclick="return confirm('Are you Sure ?')" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></a>
                          &nbsp;  <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#stock<?php echo e($p->id); ?>">Stock</button>
                         <div id="stock<?php echo e($p->id); ?>" class="modal fade" role="dialog" style="color: black">
                          <div class="modal-dialog" style="max-width: 600px;">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Stock</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <div class="modal-body">
                                <?php
                                if(!empty($p->zalando_sizes)){
                            $sizes = $p->zalando_sizes;
                                }else{
                                  $sizes = $p->variants;
                                }
                                ?>
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong>Ean : </strong><?php echo e(!empty($size['ean'])?$size['ean']:''); ?> &nbsp;&nbsp;  <strong>Sku : </strong><?php echo e(!empty($size['sku'])?$size['sku']:''); ?> &nbsp;&nbsp;<strong>Size : </strong><?php echo e(!empty($size['title'])?$size['title']:''); ?> &nbsp;&nbsp; <strong>Quantity :</strong> <?php echo e(!empty($size['quantity'])?$size['quantity']:'N/A'); ?>

                                <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </div>

                          </div>
                        </div>
                        <?php if(!is_null($p->errors) && $p->errors->count() > 0): ?>
                    
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal<?php echo e($p->id); ?>"><i class="fas fa-question-circle"></i></button>
                    

                        <!-- Modal -->
                        <div id="myModal<?php echo e($p->id); ?>" class="modal fade" role="dialog" style="color: black">
                          <div class="modal-dialog modal-lg">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">Rejection Reasons</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                              </div>
                              <div class="modal-body">
                                <?php $__currentLoopData = $p->errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong>Ean :</strong><?php echo e($error->ean); ?> &nbsp;&nbsp; <strong>Code :</strong><?php echo e($error->status_code); ?><br>
                                <p><?php echo e($error->message); ?></p>
                                <p><?php echo e($error->detail); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                            </div>

                          </div>
                        </div>
                       
                        <?php endif; ?>
                       </td>
                   </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
           </table>
       </div>
       <?php echo $products->links(); ?>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script type="text/javascript">
    setTimeout(function(){ document.getElementById("removemessage").remove(); }, 6000);
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u935545640/domains/myzpanel.com/public_html/irvalda/resources/views/products.blade.php ENDPATH**/ ?>