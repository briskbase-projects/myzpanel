<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductError extends Model
{
    //
    public $table = "product_errors";

}
